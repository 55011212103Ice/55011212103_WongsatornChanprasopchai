//
//  ViewController.swift
//  Exam1_55011212103
//
//  Created by student on 10/10/14.
//  Copyright (c) 2014 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate {
    
    let tableData = [3, 5, 10]
    let cellIdentifier = "cellIdentifier"
    
    @IBOutlet var inputName: UITextField!
    @IBOutlet var inputVolume: UITextField!
    @IBOutlet var inputPrice: UITextField!
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet var ltotal: UILabel!
    
    @IBAction func bTotal(sender: AnyObject) {
        var volume = Double((inputVolume.text as NSString).doubleValue)
        var price = Double((inputPrice.text as NSString).doubleValue)
        var sum = volume*price
        ltotal.text = "\(sum) Baht"
    }
    @IBAction func bProfit(sender: AnyObject) {
        tableView.reloadData()
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: self.cellIdentifier)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionInTableView(tableView: UITableView!) -> Int {
        return 1
    }
    func tableView(tableView: UITableView!, numberOfRowsInSection section:Int) ->Int {
        return tableData.count
    }
    func tableView(tableView: UITableView!, cellForRowAtIndexPath indexPath: NSIndexPath!) -> UITableViewCell!{
        var cell = tableView!.dequeueReusableCellWithIdentifier(self.cellIdentifier) as UITableViewCell
        var profit : [Double] = [0, 0, 0]
        
        var volume = Double((inputVolume.text as NSString).doubleValue)
        var price = Double((inputPrice.text as NSString).doubleValue)
        
        profit[0] = volume*(price*(3/100))
        profit[1] = volume*(price*(5/100))
        profit[2] = volume*(price*(10/100))
        
        let newProfit = profit[indexPath.row]
        let data = tableData[indexPath.row]
        
        cell.textLabel!.text = "ราคาหุ้นที่ \(self.tableData[indexPath.row])% : กำไร \(profit[indexPath.row]) บาท"
        return cell
    }
    func tableView(tableView: UITableView!, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    }


}

